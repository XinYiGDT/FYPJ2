﻿namespace Photon.Common.Authentication
{
    public enum AccountServiceResult
    {
        Ok,
        NotFound,
        Timeout,
        Error
    }
}
